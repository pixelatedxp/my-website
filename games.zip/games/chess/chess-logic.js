/*
   Pixelis Chess Lab — chess-logic.js
   Uses local stockfish.js (no cross-origin restrictions)
*/

let board   = null;
let game    = new Chess();
let stockfish = null;
let playerTurn = true; // true = player's turn (White)

const botChat    = document.getElementById('botChat');
const moveHistEl = document.getElementById('moveHistory');
const statusEl   = document.getElementById('gameStatus');

// ---- Personality Quotes ----
const quotes = {
    start:     ["Good luck. You'll need it.", "Let's go. Try not to embarrass yourself.", "A new game? Interesting choice."],
    pawnTake:  ["A pawn? Generous of you.", "Small wins add up.", "Every pawn counts."],
    heavyTake: ["Oh— nice. You actually saw that.", "I'll allow it. For now.", "Calculated risk. Mostly."],
    check:     ["Check. Think carefully.", "Your king is nervous.", "Pressure is on."],
    userGood:  ["Hmm. That's decent.", "I didn't see that coming.", "Annoying. But manageable."],
    userBlund: ["Are you sure about that?", "Blunders are free. Take more.", "Interesting... if you enjoy losing."],
    resign:    ["Smart. Accepting the inevitable.", "Checkmate was around the corner.", "Better luck next time."],
    win:       ["Checkmate. As expected.", "Game over.", "Maybe try 800 Elo next time."],
    lose:      ["Wait... how? Beginner's luck.", "I let you win. Clearly.", "Impressive. Genuinely."]
};

function rnd(cat) {
    const arr = quotes[cat];
    return arr[Math.floor(Math.random() * arr.length)];
}

function say(text) {
    botChat.innerText = text;
    botChat.style.opacity = '0.5';
    setTimeout(() => { botChat.style.opacity = '1'; }, 100);
}

function updateHistory() {
    const hist = game.history();
    let html = '<div class="move-history-header">Move History</div>';
    for (let i = 0; i < hist.length; i += 2) {
        html += `<div class="move-row">
            <span class="num">${Math.floor(i/2 + 1)}.</span>
            <span class="white-move">${hist[i]}</span>
            <span class="black-move">${hist[i+1] || ''}</span>
        </div>`;
    }
    moveHistEl.innerHTML = html;
    moveHistEl.scrollTop = moveHistEl.scrollHeight;
}

function setStatus(text) {
    statusEl.innerText = text;
}

// ---- Stockfish (local file = no CORS) ----
function initEngine() {
    try {
        stockfish = new Worker('stockfish.js');
        stockfish.onmessage = function(e) {
            const msg = e.data;
            if (typeof msg === 'string' && msg.startsWith('bestmove')) {
                const mv = msg.split(' ')[1];
                if (mv && mv !== '(none)') makeBotMove(mv);
            }
        };
        stockfish.postMessage('uci');
        stockfish.postMessage('setoption name Skill Level value 8'); // ~1100 Elo
        stockfish.postMessage('isready');
        setStatus('White to move.');
    } catch(err) {
        console.error('Engine error:', err);
        setStatus('Engine failed to load. Check console.');
    }
}

function askEngine() {
    if (!stockfish) return;
    setStatus('Thinking...');
    stockfish.postMessage('position fen ' + game.fen());
    stockfish.postMessage('go depth 12');
}

function makeBotMove(moveStr) {
    const move = game.move({
        from: moveStr.slice(0, 2),
        to:   moveStr.slice(2, 4),
        promotion: 'q'
    });
    if (!move) return;

    board.position(game.fen());
    updateHistory();
    playerTurn = true;

    if      (game.in_checkmate())  { setStatus('Checkmate! You lose.'); say(rnd('win')); }
    else if (game.in_draw())       { setStatus('Draw.'); say("A draw. Boring."); }
    else if (game.in_check())      { setStatus("Check! Your King is attacked."); say(rnd('check')); }
    else                           { setStatus('White to move.'); }

    if (move.captured) {
        say(move.captured === 'p' ? rnd('pawnTake') : rnd('heavyTake'));
    }
}

// ---- Board callbacks ----
function onDragStart(source, piece) {
    if (!playerTurn)       return false;
    if (game.game_over())  return false;
    if (piece.startsWith('b')) return false; // player is White
    return true;
}

function onDrop(source, target) {
    const move = game.move({ from: source, to: target, promotion: 'q' });
    if (move === null) return 'snapback';

    playerTurn = false;
    updateHistory();

    if      (game.in_checkmate()) { setStatus('Checkmate! Pixel Engine wins.'); say(rnd('win')); return; }
    else if (game.in_draw())      { setStatus('Draw.'); say("A draw. Boring."); return; }

    // Random personality reaction
    if (Math.random() > 0.6) say(rnd('userGood'));

    askEngine();
}

function onSnapEnd() {
    board.position(game.fen());
}

// ---- Init Board ----
board = Chessboard('myBoard', {
    draggable:   true,
    position:    'start',
    onDragStart: onDragStart,
    onDrop:      onDrop,
    onSnapEnd:   onSnapEnd,
    pieceTheme:  'https://chessboardjs.com/img/chesspieces/wikipedia/{piece}.png'
});

initEngine();

// ---- Buttons ----
document.getElementById('resetBtn').addEventListener('click', () => {
    game = new Chess();
    board.start();
    playerTurn = true;
    updateHistory();
    setStatus('White to move.');
    say("New game? I hope you've learned something.");
});

document.getElementById('resignBtn').addEventListener('click', () => {
    if (!game.game_over()) {
        setStatus('You resigned. Pixel Engine wins.');
        say(rnd('resign'));
        playerTurn = false;
    }
});
